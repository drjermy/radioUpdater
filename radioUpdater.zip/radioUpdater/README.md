# Radiopaedia Updater
This is a helper extension for Radiopaedia. It is initially for updating references easily using CiteItRight.

# Credits
1. Jeremy Jones, Community Director
